const CHANNEL="@DRAGONMarketplace";
const CHANNEL_URL="https://t.me/DRAGONMarketplace";
const SUPPORT_URL="https://t.me/dragon_supports_bot";
const WEBHOOK_PATH="/telegram-webhook";

export default {
 async fetch(request,env,ctx) {
  const url=new URL(request.url);
  if(url.pathname==="/") return new Response("DRAGON Marketplace backend is running.");
  if(url.pathname==="/health") return Response.json({ok:true,service:"dragon-marketplace"});

  if(url.pathname==="/setup" && request.method==="GET") {
   return new Response(`<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>DRAGON setup</title><main style="font:16px Arial;max-width:440px;margin:40px auto;padding:16px"><h2>DRAGON webhook setup</h2><form method="post"><label>Setup password</label><input name="password" type="password" required style="display:block;width:100%;padding:12px;margin:12px 0"><button style="padding:12px">Register webhook</button></form></main>`,{headers:{"content-type":"text/html;charset=utf-8","cache-control":"no-store"}});
  }
  if(url.pathname==="/setup" && request.method==="POST") {
   if(!env.SETUP_PASSWORD||!env.BOT_TOKEN||!env.WEBHOOK_SECRET) return new Response("Missing required Worker secrets.",{status:500});
   const form=await request.formData();
   if(!safeEqual(String(form.get("password")||""),env.SETUP_PASSWORD)) return new Response("Incorrect setup password.",{status:403});
   if(!/^[A-Za-z0-9_-]{1,256}$/.test(env.WEBHOOK_SECRET)) return new Response("WEBHOOK_SECRET must contain only letters, numbers, _ or -.",{status:400});
   const result=await tg(env,"setWebhook",{url:url.origin+WEBHOOK_PATH,secret_token:env.WEBHOOK_SECRET,allowed_updates:["message","callback_query"]});
   return new Response(result.ok?"Webhook registered successfully. Send /start to your Telegram bot. Remove this setup route and SETUP_PASSWORD after testing.":("Telegram error: "+(result.description||"Unknown error")),{status:result.ok?200:502});
  }
  if(url.pathname===WEBHOOK_PATH && request.method==="POST") {
   if(!safeEqual(request.headers.get("X-Telegram-Bot-Api-Secret-Token")||"",env.WEBHOOK_SECRET||"")) return new Response("Unauthorized",{status:401});
   let update; try{update=await request.json()}catch{return new Response("Bad JSON",{status:400})}
   ctx.waitUntil(handleUpdate(update,env));
   return new Response("OK");
  }
  return new Response("Not found",{status:404});
 }
};

function safeEqual(a,b){if(a.length!==b.length)return false;let n=0;for(let i=0;i<a.length;i++)n|=a.charCodeAt(i)^b.charCodeAt(i);return n===0}
async function tg(env,method,body){const r=await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/${method}`,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(body)});return r.json()}
async function send(env,chat_id,text,reply_markup){return tg(env,"sendMessage",{chat_id,text,parse_mode:"HTML",...(reply_markup?{reply_markup}:{})})}
async function member(env,id){const r=await tg(env,"getChatMember",{chat_id:CHANNEL,user_id:id});return r.ok&&(["creator","administrator","member"].includes(r.result.status)||(r.result.status==="restricted"&&r.result.is_member))}
function keyboard(){return {inline_keyboard:[
 [{text:"💰 My Balance",callback_data:"balance"},{text:"🪙 Deposit",callback_data:"deposit"}],
 [{text:"🎯 Earn DRAGON",callback_data:"earn"},{text:"📣 Promote",callback_data:"promote"}],
 [{text:"👥 Refer Friends",callback_data:"refer"},{text:"📜 History",callback_data:"history"}],
 [{text:"🆘 Support",url:SUPPORT_URL}]
]}}
async function handleUpdate(u,env){
 try{
  if(u.callback_query){
   const q=u.callback_query;await tg(env,"answerCallbackQuery",{callback_query_id:q.id});
   const chat=q.message?.chat?.id;if(!chat)return;
   if(q.data==="check_join"){if(await member(env,q.from.id))await send(env,chat,"✅ Membership confirmed. Welcome!",keyboard());else await send(env,chat,"I cannot confirm yet. Join "+CHANNEL_URL);return}
   if(!(await member(env,q.from.id))){await send(env,chat,"Join our official channel first: "+CHANNEL_URL,{inline_keyboard:[[{text:"Join channel",url:CHANNEL_URL}],[{text:"Check membership",callback_data:"check_join"}]]});return}
   await menu(q.data,chat,q.from,env);return;
  }
  const m=u.message;if(!m?.from||!m.chat)return;
  const id=String(m.from.id),chat=m.chat.id,text=(m.text||"").trim();
  if(text.startsWith("/start")){
   await env.DB.prepare("INSERT OR IGNORE INTO users(telegram_user_id,username,first_name,created_at) VALUES(?,?,?,datetime('now'))").bind(id,m.from.username||null,m.from.first_name||null).run();
   await env.DB.prepare("INSERT OR IGNORE INTO user_balances(telegram_user_id,balance_units,updated_at) VALUES(?,0,datetime('now'))").bind(id).run();
   if(!(await member(env,m.from.id))){await send(env,chat,"🐉 <b>Welcome to DRAGON Marketplace!</b>\n\nJoin our official channel to continue.",{inline_keyboard:[[{text:"📢 Join channel",url:CHANNEL_URL}],[{text:"✅ Check membership",callback_data:"check_join"}]]});return}
   await send(env,chat,"🐉 <b>DRAGON Marketplace</b>\nEarn. Promote. Grow.",keyboard());return;
  }
  if(!(await member(env,m.from.id))){await send(env,chat,"Join "+CHANNEL+" first: "+CHANNEL_URL);return}
  await send(env,chat,"Choose an option below.",keyboard());
 }catch(e){console.error("Telegram update failed",e)}
}
async function menu(a,chat,user,env){
 const id=String(user.id);
 if(a==="balance"){
  const r=await env.DB.prepare("SELECT balance_units FROM user_balances WHERE telegram_user_id=?").bind(id).first();
  await send(env,chat,`💰 <b>Balance</b>\n${((r?.balance_units||0)/100).toFixed(2)} DRAGON\n\nDRAGON is an internal platform credit, not cash or withdrawable cryptocurrency.`,keyboard());
 }else if(a==="deposit"){
  await send(env,chat,"🪙 <b>Deposit addresses</b>\nMinimum: 5 USDT equivalent.\nBTC: <code>bc1q5tueekneell0twuaavs9gsacmehtr002g060m2</code>\nUSDT TRC20: <code>TBTz7KMsaJExn6yb6rXyzFPSdzuwaoLN6h</code>\nUSDT BEP20: <code>0x5eD3cA649EEA0832B3Ed22B3342Db6076071dFEe</code>\n\nDo not send funds until the deposit-verification system is connected and tested. No deposit is credited by this starter.",keyboard());
 }else if(a==="earn"){
  await send(env,chat,"🎯 <b>Task reward schedule</b>\nJoin channel/group: 750 DRAGON\nVerified rewarded ad: 100\nView post: 100\nReaction: 150\nStart promoted bot: 2,000\nPromoted Mini App: 2,000\n\nTasks are not live yet; only verified completions can earn rewards.",keyboard());
 }else if(a==="promote"){
  await send(env,chat,"📣 Campaign publishing is not enabled in this starter. Campaigns must reserve their full budget and pay only verified completions.",keyboard());
 }else if(a==="refer"){
  await send(env,chat,`👥 <b>Referral programme</b>\nFixed eligible reward: 2,500 DRAGON.\nAdvertiser commission: 1% of eligible campaign spend.\n\nYour Telegram user ID: <code>${id}</code>\nReferral crediting is not enabled until the referral channel and verified-task callback are configured.`,keyboard());
 }else if(a==="history"){
  const r=await env.DB.prepare("SELECT entry_type,amount_units,note FROM dragon_ledger WHERE telegram_user_id=? ORDER BY id DESC LIMIT 10").bind(id).all();
  const lines=(r.results||[]).map(x=>`${esc(x.entry_type)}: ${(x.amount_units/100).toFixed(2)} DRAGON — ${esc(x.note||"")}`);
  await send(env,chat,"📜 <b>Recent history</b>\n"+(lines.join("\n")||"No transactions yet."),keyboard());
 }else await send(env,chat,"Choose an option.",keyboard());
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
