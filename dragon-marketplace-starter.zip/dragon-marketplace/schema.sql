PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(
 telegram_user_id TEXT PRIMARY KEY, username TEXT, first_name TEXT,
 referred_by TEXT, terms_accepted_at TEXT, status TEXT NOT NULL DEFAULT 'active',
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS user_balances(
 telegram_user_id TEXT PRIMARY KEY REFERENCES users(telegram_user_id),
 balance_units INTEGER NOT NULL DEFAULT 0 CHECK(balance_units>=0),
 reserved_units INTEGER NOT NULL DEFAULT 0 CHECK(reserved_units>=0),
 updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS dragon_ledger(
 id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_user_id TEXT NOT NULL REFERENCES users(telegram_user_id),
 entry_type TEXT NOT NULL, amount_units INTEGER NOT NULL, note TEXT,
 reference_id TEXT UNIQUE, created_at TEXT NOT NULL DEFAULT(datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_ledger_user ON dragon_ledger(telegram_user_id,created_at DESC);
CREATE TABLE IF NOT EXISTS settings(setting_key TEXT PRIMARY KEY,setting_value TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT(datetime('now')));
CREATE TABLE IF NOT EXISTS rate_history(id INTEGER PRIMARY KEY AUTOINCREMENT,asset TEXT NOT NULL,units_per_asset TEXT NOT NULL,changed_by TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT(datetime('now')));
CREATE TABLE IF NOT EXISTS deposits(
 id INTEGER PRIMARY KEY AUTOINCREMENT,telegram_user_id TEXT NOT NULL REFERENCES users(telegram_user_id),
 asset TEXT NOT NULL,network TEXT NOT NULL,txid TEXT NOT NULL UNIQUE,destination_address TEXT NOT NULL,
 amount_atomic TEXT,amount_asset TEXT NOT NULL,rate_snapshot TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',
 provider_reference TEXT,verified_at TEXT,created_at TEXT NOT NULL DEFAULT(datetime('now'))
);
CREATE TABLE IF NOT EXISTS campaigns(
 id INTEGER PRIMARY KEY AUTOINCREMENT,advertiser_user_id TEXT NOT NULL REFERENCES users(telegram_user_id),
 category TEXT NOT NULL,target_url TEXT NOT NULL,quantity INTEGER NOT NULL CHECK(quantity>0),
 reward_per_task_units INTEGER NOT NULL,budget_units INTEGER NOT NULL,reserved_units INTEGER NOT NULL,
 spent_units INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'draft',created_at TEXT NOT NULL DEFAULT(datetime('now'))
);
CREATE TABLE IF NOT EXISTS task_claims(
 id INTEGER PRIMARY KEY AUTOINCREMENT,campaign_id INTEGER NOT NULL REFERENCES campaigns(id),
 telegram_user_id TEXT NOT NULL REFERENCES users(telegram_user_id),status TEXT NOT NULL DEFAULT 'pending',
 evidence_ref TEXT,reward_units INTEGER NOT NULL,created_at TEXT NOT NULL DEFAULT(datetime('now')),
 verified_at TEXT,UNIQUE(campaign_id,telegram_user_id)
);
CREATE TABLE IF NOT EXISTS referrals(
 id INTEGER PRIMARY KEY AUTOINCREMENT,referrer_user_id TEXT NOT NULL REFERENCES users(telegram_user_id),
 referred_user_id TEXT NOT NULL UNIQUE REFERENCES users(telegram_user_id),
 fixed_reward_units INTEGER NOT NULL DEFAULT 250000,status TEXT NOT NULL DEFAULT 'pending',
 credited_at TEXT,created_at TEXT NOT NULL DEFAULT(datetime('now'))
);
CREATE TABLE IF NOT EXISTS referral_commissions(
 id INTEGER PRIMARY KEY AUTOINCREMENT,referrer_user_id TEXT NOT NULL REFERENCES users(telegram_user_id),
 campaign_id INTEGER NOT NULL REFERENCES campaigns(id),commission_units INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending',created_at TEXT NOT NULL DEFAULT(datetime('now')),
 UNIQUE(referrer_user_id,campaign_id)
);
CREATE TABLE IF NOT EXISTS admin_users(telegram_user_id TEXT PRIMARY KEY,added_at TEXT NOT NULL DEFAULT(datetime('now')));
CREATE TABLE IF NOT EXISTS admin_audit_log(
 id INTEGER PRIMARY KEY AUTOINCREMENT,admin_user_id TEXT NOT NULL,action TEXT NOT NULL,
 old_value TEXT,new_value TEXT,reason TEXT,created_at TEXT NOT NULL DEFAULT(datetime('now'))
);
CREATE TABLE IF NOT EXISTS fraud_flags(
 id INTEGER PRIMARY KEY AUTOINCREMENT,telegram_user_id TEXT NOT NULL,category TEXT NOT NULL,
 details TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open',created_at TEXT NOT NULL DEFAULT(datetime('now'))
);
INSERT OR IGNORE INTO settings(setting_key,setting_value) VALUES
 ('usdt_to_dragon','62500'),('minimum_deposit_usdt','5'),
 ('referral_fixed_reward','2500'),('advertiser_referral_commission_percent','1'),
 ('membership_protection_days','14');
