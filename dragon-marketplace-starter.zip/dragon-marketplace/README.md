# DRAGON Marketplace starter
Upload these files to your GitHub repository.

## Required setup
- Cloudflare Worker secrets: BOT_TOKEN, WEBHOOK_SECRET, SETUP_PASSWORD
- WEBHOOK_SECRET accepts only letters, digits, underscore and hyphen.
- Create Cloudflare D1 database and run schema.sql.
- Bind D1 to Worker using binding name DB.
- Replace database_id in wrangler.toml with your actual D1 database ID.
- Optional Worker variable: BOT_USERNAME (without @).
- Deploy Worker, then open /setup and enter SETUP_PASSWORD.
- Make the bot administrator of @DRAGONMarketplace for membership checks.
- After successful webhook setup, remove the /setup route and SETUP_PASSWORD secret.

## Honest limitations
This is a starter foundation, not a complete live marketplace. Deposit addresses are displayed, but deposits are never credited automatically. A blockchain verification provider must be integrated and tested first. Campaign publishing, reward crediting, ads, screenshot review, 14-day membership enforcement, referral payout, and admin dashboard/actions are not yet implemented. Never share private keys or seed phrases.
